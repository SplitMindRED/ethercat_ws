#include <ros/ros.h>
#include "ethercat.h"
#include "string.h"
#include <oshw.h>
#include <iostream>
#include <bitset>
#include <std_msgs/Byte.h>


//STATUSWORD
#define SW_READY_TO_SWITCH_ON          (1 << 0)
#define SW_SWITCHED_ON                 (1 << 1)
#define SW_OPERATION_ENABLED           (1 << 2)
#define SW_FAULT                       (1 << 3)
#define SW_VOLTAGE_ENABLED             (1 << 4)
#define SW_QUICK_STOP                  (1 << 5)
#define SW_SWITCH_ON_DISABLED          (1 << 6)
#define SW_WARNING                     (1 << 7)
#define SW_MANUFACTURER_SPECIFIC       (1 << 8)
#define SW_REMOTE                      (1 << 9)
#define SW_OPERATION_MODE_SPECIFIC     (1 << 10)
#define SW_INTERNAL_LIMIT_ACTIVE       (1 << 11)
#define SW_OPERATION_MODE_SPECIFIC_1   (1 << 12)
#define SW_OPERATION_MODE_SPECIFIC_2   (1 << 13)
#define SW_MANUFACTURER_SPECIFIC_1     (1 << 14)
#define SW_MANUFACTURER_SPECIFIC_2     (1 << 15)

//CONTROLWORD
#define CW_SWITCH_ON                   (1 << 0)
#define CW_ENABLE_VOLTAGE              (1 << 1)
#define CW_QUICKSTOP                   (1 << 2)
#define CW_ENABLE_OPERATION            (1 << 3)
#define CW_OPERATION_MODE_SPECIFIC_1   (1 << 4)
#define CW_OPERATION_MODE_SPECIFIC_2   (1 << 5)
#define CW_OPERATION_MODE_SPECIFIC_3   (1 << 6)
#define CW_FAULT_RESET                 (1 << 7)
#define CW_HALT                        (1 << 8)
#define CW_OPERATION_MODE_SPECIFIC_4   (1 << 9)
//10 IS RESERVED
#define CW_INTERNAL_LIMIT_ACTIVE       (1 << 11)
#define CW_MANUFACTURER_SPECIFIC_1     (1 << 12)
#define CW_MANUFACTURER_SPECIFIC_2     (1 << 13)
#define CW_MANUFACTURER_SPECIFIC_3     (1 << 14)
#define CW_MANUFACTURER_SPECIFIC_4     (1 << 15)

using namespace std;

static char IOmap[4096];

struct Output
{
  uint16_t controlword;
  int8_t modes_of_operation;
  int32_t target_position;
  uint32_t profile_velocity;
  int32_t target_velocity;
  int16_t target_torque;
  int32_t velocity_offset;
  int16_t torque_offset;
}static output;

struct Input
{
  uint16_t statusword;
  int8_t modes_of_operation_display;
  int32_t position_actual_value;
  int32_t velocity_actual_value;
  int16_t torque_actual_value;
  int32_t multiturns;
}static input;

struct Statusword
{
  bool ready_to_switch_on;        //0
  bool switched_on;               //1
  bool operation_enabled;         //2
  bool fault;                     //3
  bool voltage_enbled;            //4
  bool quick_stop;                //5
  bool switch_on_disabled;        //6
  bool warning;                   //7
  bool manufacturer_specific;     //8
  bool remote;                    //9
  bool operation_mode_specific;   //10
  bool internal_limit_active;     //11
  bool operation_mode_specific_1; //12
  bool operation_mode_specific_2; //13
  bool manufacturer_specific_1;   //14
  bool manufacturer_specific_2;   //15
}static statusword;

void initialization()
{
  /* initialise SOEM, bind socket to ifname */
  if (ec_init("enp2s0"))
  {
    cout << "Initializing EtherCAT on " << "enp2s0" << " with communication thread"  << endl;
    /* find and auto-config slaves */
    if (ec_config(TRUE, &IOmap) > 0)
    {

      cout << ec_slavecount << " EtherCAT slaves found and configured." << endl;

      /* wait for all slaves to reach SAFE_OP state */
      ec_statecheck(0, EC_STATE_SAFE_OP, EC_TIMEOUTSTATE);
      if (ec_slave[0].state != EC_STATE_SAFE_OP)
      {
//        cout << "Not all EtherCAT slaves reached safe operational state." << endl;
        ROS_WARN("Not all EtherCAT slaves reached safe operational state.");
        ec_readstate();
        //If not all slaves operational find out which one
        for (int i = 1; i <= ec_slavecount; i++)
        {
          if (ec_slave[i].state != EC_STATE_SAFE_OP)
          {
            cout << "Slave " << i << " State=" << ec_slave[i].state << " StatusCode=" << ec_slave[i].ALstatuscode << " : " << ec_ALstatuscode2string(ec_slave[i].ALstatuscode) << endl;

          }
        }
      }

      //Read the state of all slaves
      //ec_readstate();

      cout << "Request operational state for all EtherCAT slaves" << endl;

      ec_slave[0].state = EC_STATE_OPERATIONAL;
      // request OP state for all slaves
      /* send one valid process data to make outputs in slaves happy*/
      ec_send_processdata();
      ec_receive_processdata(EC_TIMEOUTRET);
      /* request OP state for all slaves */
      ec_writestate(0);

      // wait for all slaves to reach OP state
      ec_statecheck(0, EC_STATE_OPERATIONAL, EC_TIMEOUTSTATE);
      if (ec_slave[0].state == EC_STATE_OPERATIONAL)
      {
        cout << "Operational state reached for all EtherCAT slaves." << endl;
      }
    }
  }
  else
  {
    ROS_ERROR("Ethercat init failed");
  }
}

int16_t getInt16(uint8_t* &ptr)
{
  int16_t return_value;

  return_value = *ptr++;
  return_value += *ptr++ << 8;

  return return_value;
}

int32_t getInt32(uint8_t* &ptr)
{
  int32_t return_value;

  return_value = *ptr++;
  return_value += *ptr++ << 8;
  return_value += *ptr++ << 16;
  return_value += *ptr++ << 24;

  return return_value;
}

int8_t getInt8(uint8_t* &ptr)
{
  int8_t return_value;

  return_value = *ptr++;

  return return_value;
}

void setInt32(uint8_t* &ptr, int32_t value)
{
  *ptr++ = value;
  *ptr++ = value >> 8;
  *ptr++ = value >> 16;
  *ptr++ = value >> 24;
}

void setInt16(uint8_t* &ptr, int32_t value)
{
  *ptr++ = value;
  *ptr++ = value >> 8;
}

void setInt8(uint8_t* &ptr, int32_t value)
{
  *ptr++ = value;
}

void getInputTable(uint16 slave_no)
{
  uint8_t* data_ptr;
  //get first data address
  data_ptr = ec_slave[slave_no].inputs;

  input.statusword = getInt16(data_ptr);

  input.modes_of_operation_display = getInt8(data_ptr);

  input.position_actual_value = getInt32(data_ptr);

  input.velocity_actual_value = getInt32(data_ptr);

  input.torque_actual_value = getInt16(data_ptr);

  input.multiturns = getInt32(data_ptr);
}

void parseStatusword()
{
  statusword.ready_to_switch_on = input.statusword & (1 << 0);
  statusword.switched_on = (input.statusword & (1 << 1)) >> 1;
  statusword.operation_enabled = (input.statusword & (1 << 2)) >> 2;
  statusword.fault = (input.statusword & (1 << 3)) >> 3;
  statusword.voltage_enbled  = (input.statusword & (1 << 4)) >> 4;
  statusword.quick_stop  = (input.statusword & (1 << 5)) >> 5;
  statusword.switch_on_disabled  = (input.statusword & (1 << 6)) >> 6;
  statusword.warning  = (input.statusword & (1 << 7)) >> 7;
  statusword.manufacturer_specific  = (input.statusword & (1 << 8)) >> 8;
  statusword.remote = (input.statusword & (1 << 9)) >> 9;
  statusword.operation_mode_specific  = (input.statusword & (1 << 10)) >> 10;
  statusword.internal_limit_active = (input.statusword & (1 << 11)) >> 11;
  statusword.operation_mode_specific_1  = (input.statusword & (1 << 12)) >> 12;
  statusword.operation_mode_specific_2  = (input.statusword & (1 << 13)) >> 13;
  statusword.manufacturer_specific_1  = (input.statusword & (1 << 14)) >> 14;
  statusword.manufacturer_specific_2  = (input.statusword & (1 << 15)) >> 15;
}

void printStatusword()
{
  cout << "Ready to switch on: " << statusword.ready_to_switch_on << endl;
  cout << "Switched on: " << statusword.switched_on << endl;
  cout << "Operation enabled: " << statusword.operation_enabled << endl;
  cout << "Fault: " << statusword.fault << endl;
  cout << "Voltage enabled: " << statusword.voltage_enbled << endl;
  cout << "Quick stop: " << statusword.quick_stop << endl;
  cout << "Switch on disabled: " << statusword.switch_on_disabled << endl;
  cout << "Warning: " << statusword.warning << endl;
  cout << "Manufacturer specific: " << statusword.manufacturer_specific << endl;
  cout << "Remote: " << statusword.remote << endl;
  cout << "Operation mode specific: " << statusword.operation_mode_specific << endl;
  cout << "Internal limit active: " << statusword.internal_limit_active << endl;
  cout << "Operation mode specific 1: " << statusword.operation_mode_specific_1 << endl;
  cout << "Operation mode specific 2: " << statusword.operation_mode_specific_2 << endl;
  cout << "Manufacturer specific 1: " << statusword.manufacturer_specific_1 << endl;
  cout << "Manufacturer specific 2: " << statusword.manufacturer_specific_2 << endl;
}

void printInputTable()
{
  //cout << "Statusword: " << bitset<8>(input.statusword) << endl;
  cout << "Statusword: " << input.statusword << endl;
  cout << "modes_of_operation_display: " << (int)input.modes_of_operation_display << endl;
  cout << "position_actual_value: " << input.position_actual_value << endl;
  cout << "velocity_actual_value: " << input.velocity_actual_value << endl;
  cout << "torque_actual_value: " << input.torque_actual_value << endl;
  cout << "multiturns: " << input.multiturns << endl << endl;
}

void setOutputTable(uint16 slave_no)
{
  uint8_t* data_ptr;
  data_ptr = ec_slave[slave_no].outputs;

  setInt16(data_ptr,  output.controlword);
  setInt8(data_ptr,  output.modes_of_operation);
  setInt32(data_ptr,  output.target_position);
  setInt32(data_ptr,  output.profile_velocity);
  setInt32(data_ptr,  output.target_velocity);
  setInt16(data_ptr,  output.target_torque);
  setInt32(data_ptr,  output.velocity_offset);
  setInt16(data_ptr,  output.torque_offset);
}

void transferData()
{
  setOutputTable(0);

  ec_send_processdata();
  ec_receive_processdata(EC_TIMEOUTRET);

  getInputTable(0);
}

void cmdCallback(const std_msgs::Byte msg)
{
  switch(msg.data)
  {
  //fault reset
  case 0:
    output.controlword = CW_FAULT_RESET;
    //output.controlword = 1 << 7;

    ROS_WARN("Reset!");

    setOutputTable(1);
    break;

  //shutdown
  case 1:
    output.controlword = CW_ENABLE_VOLTAGE | CW_QUICKSTOP;
    //output.controlword = (1 << 1) | (1 << 2);

    ROS_WARN("Shutdown!");

    setOutputTable(1);
    break;

  //switch on
  case 2:
    output.controlword = CW_SWITCH_ON | CW_ENABLE_VOLTAGE | CW_QUICKSTOP | CW_ENABLE_OPERATION;
    //output.controlword = (1 << 0) | (1 << 1) | (1 << 2);

    ROS_WARN("Enable operation + Switch ON!");

    setOutputTable(1);
    break;

  //enable operation
  case 3:
    output.controlword = CW_SWITCH_ON | CW_ENABLE_VOLTAGE | CW_ENABLE_OPERATION;
    //output.controlword = (1 << 0) | (1 << 1) | (1 << 2) | (1 << 3);

    ROS_WARN("Enable operation and disable quick stop!");

    setOutputTable(1);
    break;

  //set mode of operation to profile position mode
  case 4:
    output.modes_of_operation = 1;
    //output.controlword = CW_SWITCH_ON | CW_ENABLE_VOLTAGE | CW_ENABLE_OPERATION | (1 << 4) | (1 << 5);

    ROS_WARN("Profile position mode set!");

    setOutputTable(1);
    break;

case 14:
  //output.modes_of_operation = 1;
  output.target_position = 400000;
  output.profile_velocity = 20;
  output.controlword = CW_SWITCH_ON | CW_ENABLE_VOLTAGE | CW_QUICKSTOP | CW_ENABLE_OPERATION | (1 << 4) | (1 << 5);

  ROS_WARN("Profile position mode start!");

  setOutputTable(1);
  break;

    //set velocity mode
    case 5:
      output.modes_of_operation = 3;
      output.target_velocity = -15;
      //output.target_velocity = 20;
//      output.controlword = CW_SWITCH_ON | CW_ENABLE_VOLTAGE | CW_ENABLE_OPERATION | (1 << 4) | (1 << 5);

      ROS_WARN("Velocity mode set!");

      setOutputTable(1);
      break;

    //homing
    case 6:
      output.modes_of_operation = 6;
      //output.controlword = (1 << 4) | CW_SWITCH_ON | CW_ENABLE_VOLTAGE | CW_ENABLE_OPERATION;

      ROS_WARN("Homing mode!");

      setOutputTable(1);
      break;

    //homing
    case 7:
      output.controlword = (1 << 4) | CW_SWITCH_ON | CW_ENABLE_VOLTAGE | CW_QUICKSTOP | CW_ENABLE_OPERATION;

      ROS_WARN("Homing mode start!");

      setOutputTable(1);
      break;
  }
}

int main(int argc, char **argv)
{
  ros::init(argc, argv, "test_festo");
  ros::NodeHandle nh;
  ros::Rate loop_rate(10);
  ros::Rate sleep(1);

  ros::Subscriber cmd_topic = nh.subscribe("cmd", 1, cmdCallback);

  ROS_INFO("Ethercat initialization...");

  initialization();

//  getInputTable(1);

//  parseStatusword();
//  printStatusword();
//  printInputTable();

  //  uint8_t* ptr = ec_slave[1].outputs;

  //  cout << getInt16(ptr) << endl;

  //reset
//  output.controlword = 1 << 7;

//  setOutputTable(1);

//  ec_send_processdata();
//  ec_receive_processdata(EC_TIMEOUTRET);

//  loop_rate.sleep();
//  loop_rate.sleep();
//  loop_rate.sleep();

  //sleep.sleep();


  //switch on
//  output.controlword = 1;// | (1 << 1) | (1 << 3);

//  setOutputTable(1);

//  ec_send_processdata();
//  ec_receive_processdata(EC_TIMEOUTRET);

//  loop_rate.sleep();

  while(ros::ok())
  {
    getInputTable(1);

    parseStatusword();
    printStatusword();
    printInputTable();

    ec_send_processdata();
    ec_receive_processdata(EC_TIMEOUTRET);

    ros::spinOnce();
    loop_rate.sleep();
  }
}
