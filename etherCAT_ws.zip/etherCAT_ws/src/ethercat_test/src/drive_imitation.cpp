#include <drive_imitation/drive_imitation.h>

using namespace std;

Drive_Imitation::Drive_Imitation(ros::NodeHandle& nh)
{
  _nh = nh;

  _current_position = 0;
  _target_position = 0;
  _current_velocity = 0;
  _target_velocity = 0;
  _mode = VELOCITY;
  _isMoving = 0;
}

bool Drive_Imitation::init()
{
  _srv_switch_mode = _nh.advertiseService(ros::this_node::getName() + "/switch_mode", &Drive_Imitation::_srv_SwitchMode, this);
  _srv_set_vel = _nh.advertiseService(ros::this_node::getName() + "/set_vel", &Drive_Imitation::_srv_SetVel, this);
  _srv_set_pos = _nh.advertiseService(ros::this_node::getName() + "/set_pos", &Drive_Imitation::_srv_SetPos, this);
  _srv_start_move = _nh.advertiseService(ros::this_node::getName() + "/start_move", &Drive_Imitation::_srv_StartMoving, this);
  _srv_stop_move = _nh.advertiseService(ros::this_node::getName() + "/stop_move", &Drive_Imitation::_srv_StopMoving, this);

  _pub_cur_pos = _nh.advertise<std_msgs::Int32>(ros::this_node::getName() + "/current_position", 1);
  _pub_cur_vel = _nh.advertise<std_msgs::Int32>(ros::this_node::getName() + "/current_velocity", 1);

  _sub_cmd_vel = _nh.subscribe("/cmd_vel", 1, &Drive_Imitation::cmdVelCallback, this);


  return 1;
}

void Drive_Imitation::move()
{
  if (_isMoving == true)
  {
    _current_position = _current_position + _current_velocity;
  }

  std_msgs::Int32 msg;
  msg.data = _current_position;
  _pub_cur_pos.publish(msg);
  msg.data = _current_velocity;
  _pub_cur_vel.publish(msg);
}


void Drive_Imitation::setPos(int32_t Pt)
{
  _target_position = Pt;
}

void Drive_Imitation::setVel(int32_t Vt)
{
  _target_velocity = Vt;
}

int32_t Drive_Imitation::getPos()
{
  return _current_position;
}

int32_t Drive_Imitation::getVel()
{
  return _current_velocity;
}

void Drive_Imitation::switchMode(uint8_t mode)
{
  _mode = mode;
}

uint8_t Drive_Imitation::getMode()
{
  return _mode;
}

bool Drive_Imitation::_srv_StopMoving(std_srvs::Trigger::Request& req, std_srvs::Trigger::Response& res)
{
  _isMoving = false;

  res.message = "Drive stops moving";
  res.success = true;
  return true;
}

bool Drive_Imitation::_srv_StartMoving(std_srvs::Trigger::Request& req, std_srvs::Trigger::Response& res)
{
  _isMoving = true;

  res.message = "Drive starts moving";
  res.success = true;
  return true;
}

bool Drive_Imitation::_srv_SwitchMode(rtc_bridge_srv::setInt16::Request& req, rtc_bridge_srv::setInt16::Response& res)
{
  if ((uint8_t)req.value == POSITION)
  {
    _mode = (uint8_t)req.value;
    res.message = "Position mode";
  }
  else if ((uint8_t)req.value == VELOCITY)
  {
    _mode = (uint8_t)req.value;
    res.message = "Velocity mode";
  }

  res.success = true;
  return true;
}

bool Drive_Imitation::_srv_SetVel(rtc_bridge_srv::setInt32::Request& req, rtc_bridge_srv::setInt32::Response& res)
{
  _current_velocity = req.value;

  res.message = "Velocity set to " + std::to_string(req.value);
  res.success = true;

  return true;
}

bool Drive_Imitation::_srv_SetPos(rtc_bridge_srv::setInt32::Request &req, rtc_bridge_srv::setInt32::Response &res)
{
  _current_position = req.value;

  res.message = "Position set to " + std::to_string(req.value);
  res.success = true;

  return true;
}
