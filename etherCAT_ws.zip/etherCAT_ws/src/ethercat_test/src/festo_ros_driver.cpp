#include <festo_ros_driver/festo_ros_driver.h>

using namespace std;

Festo::Festo(ros::NodeHandle& nh)
{
  _nh = nh;

  // connect and register the joint state interface
  hardware_interface::JointStateHandle state_handle_a("A", &pos[0], &vel[0], &eff[0]);
  joint_state_interface.registerHandle(state_handle_a);

  hardware_interface::JointStateHandle state_handle_b("B", &pos[1], &vel[1], &eff[1]);
  joint_state_interface.registerHandle(state_handle_b);

  registerInterface(&joint_state_interface);

  // connect and register the joint position interface
  hardware_interface::JointHandle pos_handle_a(joint_state_interface.getHandle("A"), &cmd[0]);
  joint_pos_interface.registerHandle(pos_handle_a);

  hardware_interface::JointHandle pos_handle_b(joint_state_interface.getHandle("B"), &cmd[1]);
  joint_pos_interface.registerHandle(pos_handle_b);

  registerInterface(&joint_pos_interface);
}

bool Festo::init()
{
  /* initialise SOEM, bind socket to ifname */
  if (ec_init("enp2s0"))
  {
    cout << "Initializing EtherCAT on " << "enp2s0" << " with communication thread"  << endl;

    /* find and auto-config slaves */
    if (ec_config(TRUE, &_IOmap) > 0)
    {
      cout << ec_slavecount << " EtherCAT slaves found and configured." << endl;

      /* wait for all slaves to reach SAFE_OP state */
      ec_statecheck(0, EC_STATE_SAFE_OP, EC_TIMEOUTSTATE);

      if (ec_slave[0].state != EC_STATE_SAFE_OP)
      {
        //        cout << "Not all EtherCAT slaves reached safe operational state." << endl;
        ROS_WARN("Not all EtherCAT slaves reached safe operational state.");
        ec_readstate();

        //If not all slaves operational find out which one
        for (int i = 1; i <= ec_slavecount; i++)
        {
          if (ec_slave[i].state != EC_STATE_SAFE_OP)
          {
            cout << "Slave " << i << " State =" << ec_slave[i].state << " StatusCode =" << ec_slave[i].ALstatuscode << " : " << ec_ALstatuscode2string(ec_slave[i].ALstatuscode) << endl;
          }
        }
      }

      //Read the state of all slaves
      ec_readstate();

      cout << "Request operational state for all EtherCAT slaves" << endl;

      ec_slave[0].state = EC_STATE_OPERATIONAL;
      // request OP state for all slaves
      /* send one valid process data to make outputs in slaves happy*/
      ec_send_processdata();
      ec_receive_processdata(EC_TIMEOUTRET);
      /* request OP state for all slaves */
      ec_writestate(0);

      // wait for all slaves to reach OP state
      ec_statecheck(0, EC_STATE_OPERATIONAL, EC_TIMEOUTSTATE);

      if (ec_slave[0].state == EC_STATE_OPERATIONAL)
      {
        cout << "Operational state reached for all EtherCAT slaves." << endl;
        return true;
      }
      else
      {
        cout << YELLOW("Operational state did NOT reached for all EtherCAT slaves.") << endl;
        return true;
      }
    }
    else
    {
      //if no slaves found?
      cout << YELLOW("No EtherCAT slaves were found") << endl;
      return true;
    }
  }
  else
  {
    return false;
  }
}

