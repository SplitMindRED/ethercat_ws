#include <ros/ros.h>
#include "ethercat.h"
#include "string.h"
#include <oshw.h>
#include <iostream>

#define NUMBER_OF_SLAVES      11
#define KR_845                 1

using namespace std;

char IOmap[4096];

int32 get_input_int32(uint16 slave_no, uint8 module_index)
{
   int32 return_value;
   uint8 *data_ptr;
   /* Get the IO map pointer from the ec_slave struct */
   data_ptr = ec_slave[slave_no].inputs;

   /* Move pointer to correct module index */
   data_ptr += module_index * 4;
   /* Read value byte by byte since all targets can't handle misaligned
    * addresses
    */
   return_value = *data_ptr++;
   return_value += (*data_ptr++ << 8);
   return_value += (*data_ptr++ << 16);
   return_value += (*data_ptr++ << 24);

   return return_value;
}

void set_input_int32 (uint16 slave_no, uint8 module_index, int32 value)
{
   uint8 *data_ptr;
   /* Get the IO map pointer from the ec_slave struct */
   data_ptr = ec_slave[slave_no].inputs;
   /* Move pointer to correct module index */
   data_ptr += module_index * 4;
   /* Read value byte by byte since all targets can handle misaligned
    * addresses
    */
   *data_ptr++ = (value >> 0) & 0xFF;
   *data_ptr++ = (value >> 8) & 0xFF;
   *data_ptr++ = (value >> 16) & 0xFF;
   *data_ptr++ = (value >> 24) & 0xFF;
}

int32 get_output_int32(uint16 slave_no, uint8 byte_index)
{
   int32 return_value;
   uint8 *data_ptr;

   /* Get the IO map pointer from the ec_slave struct */
   data_ptr = ec_slave[slave_no].outputs;
   /* Move pointer to correct module index */
   data_ptr += byte_index;
   /* Read value byte by byte since all targets can handle misaligned
    * addresses
    */
   return_value = *data_ptr++;
   return_value += (*data_ptr++ << 8);
   return_value += (*data_ptr++ << 16);
   return_value += (*data_ptr++ << 24);

   return return_value;
}

int16 get_output_int16(uint16 slave_no, uint8 byte_index)
{
   int16 return_value;
   uint8 *data_ptr;

   /* Get the IO map pointer from the ec_slave struct */
   data_ptr = ec_slave[slave_no].outputs;
   /* Move pointer to correct module index */
   data_ptr += byte_index;
   /* Read value byte by byte since all targets can handle misaligned
    * addresses
    */
   return_value = *data_ptr++;
   return_value += (*data_ptr++ << 8);

   return return_value;
}

uint8 get_output_uint8(uint16 slave_no, uint8 byte_index)
{
   uint8 return_value;
   uint8 *data_ptr;

   /* Get the IO map pointer from the ec_slave struct */
   data_ptr = ec_slave[slave_no].outputs;
   /* Move pointer to correct module index */
   data_ptr += byte_index;
   /* Read value byte by byte since all targets can handle misaligned
    * addresses
    */
   return_value = *data_ptr++;

   return return_value;
}

void set_output_int16 (uint16 slave_no, uint8 module_index, int16 value)
{
   uint8 *data_ptr;
   /* Get the IO map pointer from the ec_slave struct */
   data_ptr = ec_slave[slave_no].outputs;
   /* Move pointer to correct module index */
   data_ptr += module_index * 2;
   /* Read value byte by byte since all targets can handle misaligned
    * addresses
    */
   *data_ptr++ = (value >> 0) & 0xFF;
   *data_ptr++ = (value >> 8) & 0xFF;
}

void set_controller_mode(uint16 slave_no, uint8 byte_index, uint8_t value)
{
  uint8 *data_ptr;
  /* Get the IO map pointer from the ec_slave struct */
  data_ptr = ec_slave[slave_no].outputs;
  /* Move pointer to correct module index */
  data_ptr += byte_index;
  /* Read value byte by byte since all targets can handle misaligned
   * addresses
   */
  *data_ptr++ = (value >> 0) & 0xFF;
}

void set_reference(uint16 slave_no, uint8 byte_index, int32 value)
{
  uint8 *data_ptr;
  /* Get the IO map pointer from the ec_slave struct */
  data_ptr = ec_slave[slave_no].outputs;
  /* Move pointer to correct module index */
  data_ptr += byte_index;
  /* Read value byte by byte since all targets can handle misaligned
   * addresses
   */
  *data_ptr++ = (value >> 0) & 0xFF;
}

void set_output_bit (uint16 slave_no, uint8 module_index, uint8 value)
{
   /* Get the the startbit position in slaves IO byte */
   uint8 startbit = ec_slave[slave_no].Ostartbit;
   /* Set or Clear bit */
   if (value == 0)
      *ec_slave[slave_no].outputs &= ~(1 << (module_index - 1 + startbit));
   else
      *ec_slave[slave_no].outputs |= (1 << (module_index - 1 + startbit));
}

void slaveinfo(char *ifname)
{
   int cnt, i, j, nSM;
    uint16 ssigen;
    int expectedWKC;

   printf("Starting slaveinfo\n");

   /* initialise SOEM, bind socket to ifname */
   if (ec_init(ifname))
   {
      printf("ec_init on %s succeeded.\n",ifname);
      /* find and auto-config slaves */
      if ( ec_config(FALSE, &IOmap) > 0 )
      {
         ec_configdc();
         while(EcatError) printf("%s", ec_elist2string());
         printf("%d slaves found and configured.\n",ec_slavecount);
         expectedWKC = (ec_group[0].outputsWKC * 2) + ec_group[0].inputsWKC;
         printf("Calculated workcounter %d\n", expectedWKC);
      }
   }
}

void simpletest(char *ifname)
{

//   char *ifname = arg;
   int cnt, i, j;

//   *pPORTFIO_DIR |= BIT (6);

   printf("Starting simple test\n");

   /* initialise SOEM */
   if (ec_init(ifname))
   {
      printf("ec_init succeeded.\n");

      /* find and auto-config slaves */
      if ( ec_config_init(FALSE) > 0 )
      {
         printf("%d slaves found and configured.\n",ec_slavecount);

         /* Check network  setup */
         if (1)//network_configuration())
         {
            /* Run IO mapping */
            ec_config_map(&IOmap);

            printf("Slaves mapped, state to SAFE_OP.\n");
            /* wait for all slaves to reach SAFE_OP state */
            ec_statecheck(0, EC_STATE_SAFE_OP,  EC_TIMEOUTSTATE);

            /* Print som information on the mapped network */
            for( cnt = 1 ; cnt <= ec_slavecount ; cnt++)
            {
               printf("\nSlave:%d\n Name:%s\n Output size: %dbits\n Input size: %dbits\n State: %d\n Delay: %d[ns]\n Has DC: %d\n",
                       cnt, ec_slave[cnt].name, ec_slave[cnt].Obits, ec_slave[cnt].Ibits,
                       ec_slave[cnt].state, ec_slave[cnt].pdelay, ec_slave[cnt].hasdc);
               printf(" Configured address: %x\n", ec_slave[cnt].configadr);
               printf(" Outputs address: %x\n", ec_slave[cnt].outputs);
               printf(" Inputs address: %x\n", ec_slave[cnt].inputs);

               for(j = 0 ; j < ec_slave[cnt].FMMUunused ; j++)
               {
                  printf(" FMMU%1d Ls:%x Ll:%4d Lsb:%d Leb:%d Ps:%x Psb:%d Ty:%x Act:%x\n", j,
                          (int)ec_slave[cnt].FMMU[j].LogStart, ec_slave[cnt].FMMU[j].LogLength, ec_slave[cnt].FMMU[j].LogStartbit,
                          ec_slave[cnt].FMMU[j].LogEndbit, ec_slave[cnt].FMMU[j].PhysStart, ec_slave[cnt].FMMU[j].PhysStartBit,
                          ec_slave[cnt].FMMU[j].FMMUtype, ec_slave[cnt].FMMU[j].FMMUactive);
               }
               printf(" FMMUfunc 0:%d 1:%d 2:%d 3:%d\n",
                        ec_slave[cnt].FMMU0func, ec_slave[cnt].FMMU1func, ec_slave[cnt].FMMU2func, ec_slave[cnt].FMMU3func);

            }

//            printf("Request operational state for all slaves\n");
//            ec_slave[0].state = EC_STATE_OPERATIONAL;
//            /* send one valid process data to make outputs in slaves happy*/
//            ec_send_processdata();
//            ec_receive_processdata(EC_TIMEOUTRET);
//            /* request OP state for all slaves */
//            ec_writestate(0);
//            /* wait for all slaves to reach OP state */
//            ec_statecheck(0, EC_STATE_OPERATIONAL,  EC_TIMEOUTSTATE);
//            if (ec_slave[0].state == EC_STATE_OPERATIONAL )
//            {
//               printf("Operational state reached for all slaves.\n");
//            }
//            else
//            {
//               printf("Not all slaves reached operational state.\n");
//               ec_readstate();
//               for(i = 1; i<=ec_slavecount ; i++)
//               {
//                  if(ec_slave[i].state != EC_STATE_OPERATIONAL)
//                  {
//                     printf("Slave %d State=0x%04x StatusCode=0x%04x\n",
//                             i, ec_slave[i].state, ec_slave[i].ALstatuscode);
//                  }
//               }
//            }


            /* Simple blinking lamps BOX demo */
//            uint8 digout = 0;

//            slave_EL4001_1.out1 = (int16)0x3FFF;
//            set_output_int16(EL4001_1,0,slave_EL4001_1.out1);

//            task_spawn ("t_StatsPrint", my_cyclic_callback, 20, 1024, (void *)NULL);
//            tt_start_wait (tt_sched[0]);

//            while(1)
//            {
//               dorun = 0;
//               slave_EL1008_1.in1 = get_input_bit(EL1008_1,1); // Start button
//               slave_EL1008_1.in2 = get_input_bit(EL1008_1,2);  // Turnkey RIGHT
//               slave_EL1008_1.in3 = get_input_bit(EL1008_1,3); // Turnkey LEFT

//               /* (Turnkey MIDDLE + Start button) OR Turnkey RIGHT OR Turnkey LEFT
//                  Turnkey LEFT: Light positions bottom to top. Loop, slow operation.
//                  Turnkey MIDDLE: Press start button to light positions bottom to top. No loop, fast operation.
//                  Turnkey RIGHT: Light positions bottom to top. Loop, fast operation.
//               */
//               if (slave_EL1008_1.in1 || slave_EL1008_1.in2 || slave_EL1008_1.in3)
//               {
//                  digout = 0;
//                  /* *ec_slave[6].outputs = digout; */
//                  /* set_output_bit(slave_name #,index as 1 output on module , value */
//                  set_output_bit(EL2622_1,1,(digout & BIT (0))); /* Start button */
//                  set_output_bit(EL2622_1,2,(digout & BIT (1))); /* Turnkey RIGHT */
//                  set_output_bit(EL2622_2,1,(digout & BIT (2))); /* Turnkey LEFT */
//                  set_output_bit(EL2622_2,2,(digout & BIT (3)));
//                  set_output_bit(EL2622_3,1,(digout & BIT (4)));
//                  set_output_bit(EL2622_3,2,(digout & BIT (5)));

//                  while(dorun < 95)
//                  {
//                     dorun++;

//                     if (slave_EL1008_1.in3)
//                        task_delay(tick_from_ms(20));
//                     else
//                        task_delay(tick_from_ms(5));

//                     digout = (uint8) (digout | BIT((dorun / 16) & 0xFF));

//                     set_output_bit(EL2622_1,1,(digout & BIT (0))); /* LED1 */
//                     set_output_bit(EL2622_1,2,(digout & BIT (1))); /* LED2 */
//                     set_output_bit(EL2622_2,1,(digout & BIT (2))); /* LED3 */
//                     set_output_bit(EL2622_2,2,(digout & BIT (3))); /* LED4 */
//                     set_output_bit(EL2622_3,1,(digout & BIT (4))); /* LED5 */
//                     set_output_bit(EL2622_3,2,(digout & BIT (5))); /* LED6 */

//                     slave_EL1008_1.in1 = get_input_bit(EL1008_1,2);  /* Turnkey RIGHT */
//                     slave_EL1008_1.in2 = get_input_bit(EL1008_1,3); /* Turnkey LEFT */
//                     slave_EL3061_1.in1 = get_input_int32(EL3061_1,0); /* Read AI */
//                  }
//               }
//               task_delay(tick_from_ms(2));

//            }
//         }
//         else
//         {
//            printf("Mismatch of network units!\n");
//         }
//      }
//      else
//      {
//         printf("No slaves found!\n");
//      }
//      printf("End simple test, close socket\n");
//      /* stop SOEM, close socket */
//      ec_close();
//   }
//   else
//   {
//      printf("ec_init failed");
//   }
//   printf("End program\n");
}
      }
   }
}

void initialization()
{
  /* initialise SOEM, bind socket to ifname */
  if (ec_init("enp2s0"))
  {
    cout << "Initializing EtherCAT on " << "enp2s0" << " with communication thread"  << endl;
    /* find and auto-config slaves */
    if (ec_config(TRUE, &IOmap) > 0)
    {

      cout << ec_slavecount << " EtherCAT slaves found and configured." << endl;

      /* wait for all slaves to reach SAFE_OP state */
      ec_statecheck(0, EC_STATE_SAFE_OP, EC_TIMEOUTSTATE);
      if (ec_slave[0].state != EC_STATE_SAFE_OP)
      {
        cout << "Not all EtherCAT slaves reached safe operational state." << endl;
        ec_readstate();
        //If not all slaves operational find out which one
        for (int i = 1; i <= ec_slavecount; i++)
        {
          if (ec_slave[i].state != EC_STATE_SAFE_OP)
          {
            cout << "Slave " << i << " State=" << ec_slave[i].state << " StatusCode=" << ec_slave[i].ALstatuscode << " : " << ec_ALstatuscode2string(ec_slave[i].ALstatuscode) << endl;

          }
        }
      }

      //Read the state of all slaves
      //ec_readstate();

      cout << "Request operational state for all EtherCAT slaves" << endl;

      ec_slave[0].state = EC_STATE_OPERATIONAL;
      // request OP state for all slaves
      /* send one valid process data to make outputs in slaves happy*/
      ec_send_processdata();
      ec_receive_processdata(EC_TIMEOUTRET);
      /* request OP state for all slaves */
      ec_writestate(0);

      // wait for all slaves to reach OP state
      ec_statecheck(0, EC_STATE_OPERATIONAL, EC_TIMEOUTSTATE);
      if (ec_slave[0].state == EC_STATE_OPERATIONAL)
      {
        cout << "Operational state reached for all EtherCAT slaves." << endl;
      }

      ec_send_processdata();
      ec_receive_processdata(EC_TIMEOUTRET);

      cout << ec_slavecount << endl;

//      for(int i = 2; i < ec_slavecount; i++)
//      {
//        cout << "Slave: " << i << endl;

//        cout << "Name: " << ec_slave[i].name << endl;
//        cout << "Inputs: " << ec_slave[i].inputs << endl;
//        cout << "Outputs: " << ec_slave[i].outputs << endl;

//        cout << "Start bits: " << ec_slave[i].Istartbit << endl;
//        cout << "Input bits: " << ec_slave[i].Ibits << endl << endl;


//      }

//      int cnt = 3;
//      cout << "Name: " << ec_slave[cnt].name << endl;
//      cout << "Inputs: " << ec_slave[cnt].inputs << endl;
//      cout << "Outputs: " << ec_slave[cnt].outputs << endl;


//      for(int i = 1; i < 10; i++)
//      {
//        cout << "i: " << i << " data: " << get_input_int32(3, i) << endl;

//        ec_send_processdata();
//        ec_receive_processdata(EC_TIMEOUTRET);
//      }
    }
  }
  else
  {
    ROS_INFO("Ethercat init failed");
  }
}

int main(int argc, char **argv)
{
  ros::init(argc, argv, "ethercat_test");
  ros::NodeHandle n;
  ros::Rate rate(5);

  ROS_INFO("Hello");

//  uint32_t res = 100;

//  res = network_configuration();

//  cout << "res: " << res << endl;

//  slaveinfo("enp2s0");

//  cout << "name" << ec_slave[2].name << endl;
//  cout << "inputs" << ec_slave[2].inputs << endl;

//  for(uint8_t i = 0; i < 10; i++)
//  {
//    cout << get_input_int32(2, i) << endl;
//  }

//  simpletest("enp2s0");

//  cout << "inputs" << ec_slave[3].inputs << endl;

  initialization();

//  set_reference(7, 0, 0);
//  set_controller_mode(7, 4, 7);

//  ec_send_processdata();
//  ec_receive_processdata(EC_TIMEOUTRET);

//  rate.sleep();

  while(ros::ok())
  {
    cout << "set pos" << endl;
//    set_input_int32(7, 1, 1);
//    set_output_int32(10, 1, 1);

//        set_reference(7, 0, 500);
//        set_controller_mode(7, 4, 4);

//        ec_send_processdata();
//        ec_receive_processdata(EC_TIMEOUTRET);

//    cout << "output" << endl;
//    cout << "0: " <<  " data: " << get_output_int32(7, 0) << endl;
//    cout << "1: " <<  " data: " << (uint8_t)get_output_uint8(7, 4) << endl;

//    //test
//    cout << "1: " <<  " data: " << (int)get_output_uint8(7, 4) << endl;

//    cout << "2: " <<  " data: " << (uint8_t)get_output_uint8(7, 5) << endl;
//    cout << "3: " <<  " data: " << get_output_int16(7, 6) << endl;


    cout << endl << "input" << endl;
    for(int i = 0; i < 10; i++)
    {
      cout << "i: " << i << " data: " << get_input_int32(7, i) << endl;
    }

    cout << endl;

    uint8_t* ptr = ec_slave[7].inputs;

    ec_send_processdata();
    ec_receive_processdata(EC_TIMEOUTRET);

    rate.sleep();
  }

  return 0;
}
