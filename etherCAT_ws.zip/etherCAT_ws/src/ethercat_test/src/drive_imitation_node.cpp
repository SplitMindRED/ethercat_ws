#include <drive_imitation/drive_imitation.h>

using namespace std;

int main(int argc, char** argv)
{
  ros::init(argc, argv, "driver_imitation_node");
  ros::NodeHandle n;
  ros::Rate loop_rate(10);

  ROS_INFO("Imitation driver initialization...");

  Drive_Imitation drive(n);

  if(!drive.init())
  {
    ROS_ERROR("Node init failed!");
    return 0;
  }

  ROS_INFO("Imitation driver initialization DONE!");
  ROS_INFO("Enter loop");

  while (ros::ok())
  {
    drive.move();

    ros::spinOnce();
    loop_rate.sleep();
  }

  return 1;
}
