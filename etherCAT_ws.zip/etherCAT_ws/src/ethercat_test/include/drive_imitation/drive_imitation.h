#pragma once

//ROS
#include <ros/ros.h>
#include <std_srvs/Trigger.h>
#include <rtc_bridge_srv/setInt32.h>
#include <rtc_bridge_srv/setInt16.h>
#include <std_msgs/Int32.h>

//C++
#include <iostream>

//My
#include <color_cout.h>

enum Mode
{
  POSITION = 1,
  VELOCITY = 2
};

class Drive_Imitation

{
 public:

  Drive_Imitation(ros::NodeHandle& nh);

  bool init();

  void move();

  void setVel(int32_t Vt);
  void setPos(int32_t Pt);

  int32_t getVel();
  int32_t getPos();
  uint8_t getMode();

  void switchMode(uint8_t mode);

 private:

  ros::NodeHandle _nh;

  ros::ServiceServer _srv_switch_mode;
  ros::ServiceServer _srv_set_vel;
  ros::ServiceServer _srv_set_pos;
  ros::ServiceServer _srv_start_move;
  ros::ServiceServer _srv_stop_move;

  ros::Publisher _pub_cur_pos;
  ros::Publisher _pub_cur_vel;
  ros::Subscriber _sub_cmd_vel;

  bool _srv_SwitchMode(rtc_bridge_srv::setInt16::Request& req, rtc_bridge_srv::setInt16::Response& res);
  bool _srv_StartMoving(std_srvs::Trigger::Request& req, std_srvs::Trigger::Response& res);
  bool _srv_StopMoving(std_srvs::Trigger::Request& req, std_srvs::Trigger::Response& res);
  bool _srv_SetVel(rtc_bridge_srv::setInt32::Request& req, rtc_bridge_srv::setInt32::Response& res);
  bool _srv_SetPos(rtc_bridge_srv::setInt32::Request& req, rtc_bridge_srv::setInt32::Response& res);


  //all units in mm
  int32_t _current_position;
  int32_t _target_position;
  int32_t _current_velocity;
  int32_t _target_velocity;
  uint8_t _mode;
  bool _isMoving;

};
