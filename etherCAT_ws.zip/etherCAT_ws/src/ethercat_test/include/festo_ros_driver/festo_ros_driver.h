#pragma once

//ROS
#include <ros/ros.h>
#include <hardware_interface/joint_command_interface.h>
#include <hardware_interface/joint_state_interface.h>
#include <hardware_interface/robot_hw.h>
#include <std_msgs/Byte.h>

//C++
#include "string.h"
#include <iostream>
#include <bitset>

//My
#include <color_cout.h>

//Other
#include "ethercat.h"
#include <oshw.h>

//STATUSWORD
#define SW_READY_TO_SWITCH_ON          (1 << 0)
#define SW_SWITCHED_ON                 (1 << 1)
#define SW_OPERATION_ENABLED           (1 << 2)
#define SW_FAULT                       (1 << 3)
#define SW_VOLTAGE_ENABLED             (1 << 4)
#define SW_QUICK_STOP                  (1 << 5)
#define SW_SWITCH_ON_DISABLED          (1 << 6)
#define SW_WARNING                     (1 << 7)
#define SW_MANUFACTURER_SPECIFIC       (1 << 8)
#define SW_REMOTE                      (1 << 9)
#define SW_OPERATION_MODE_SPECIFIC     (1 << 10)
#define SW_INTERNAL_LIMIT_ACTIVE       (1 << 11)
#define SW_OPERATION_MODE_SPECIFIC_1   (1 << 12)
#define SW_OPERATION_MODE_SPECIFIC_2   (1 << 13)
#define SW_MANUFACTURER_SPECIFIC_1     (1 << 14)
#define SW_MANUFACTURER_SPECIFIC_2     (1 << 15)

//CONTROLWORD
#define CW_SWITCH_ON                   (1 << 0)
#define CW_ENABLE_VOLTAGE              (1 << 1)
#define CW_QUICKSTOP                   (1 << 2)
#define CW_ENABLE_OPERATION            (1 << 3)
#define CW_OPERATION_MODE_SPECIFIC_1   (1 << 4)
#define CW_OPERATION_MODE_SPECIFIC_2   (1 << 5)
#define CW_OPERATION_MODE_SPECIFIC_3   (1 << 6)
#define CW_FAULT_RESET                 (1 << 7)
#define CW_HALT                        (1 << 8)
#define CW_OPERATION_MODE_SPECIFIC_4   (1 << 9)
//10 IS RESERVED
#define CW_INTERNAL_LIMIT_ACTIVE       (1 << 11)
#define CW_MANUFACTURER_SPECIFIC_1     (1 << 12)
#define CW_MANUFACTURER_SPECIFIC_2     (1 << 13)
#define CW_MANUFACTURER_SPECIFIC_3     (1 << 14)
#define CW_MANUFACTURER_SPECIFIC_4     (1 << 15)

class Festo : public hardware_interface::RobotHW

{
 public:

  Festo(ros::NodeHandle& nh);

  bool init();

 private:

  ros::NodeHandle _nh;

  ros::Publisher _pub_cmd_vel;

  char _IOmap[4096];

  hardware_interface::JointStateInterface joint_state_interface;
  hardware_interface::PositionJointInterface joint_pos_interface;

  double cmd[2];
  double pos[2];
  double vel[2];
  double eff[2];

};
