#ifndef COLOR_COUNT_H
#define COLOR_COUNT_H
//******* цветной вывод текста ***********************
#define BEFORE_RED "\033[1;31m"
#define BEFORE_GREEN "\033[1;32m"
#define BEFORE_WHITE "\033[1;37m"
#define BEFORE_BLUE "\033[1;34m"
#define BEFORE_CYAN "\033[1;36m"
#define BEFORE_YELLOW "\033[1;33m"
#define AFTER "\033[0m"
#define RED(text) BEFORE_RED << text << AFTER
#define GREEN(text) BEFORE_GREEN << text << AFTER
#define WHITE(text) BEFORE_WHITE << text << AFTER
#define BLUE(text) BEFORE_BLUE << text << AFTER
#define CYAN(text) BEFORE_CYAN << text << AFTER
#define YELLOW(text) BEFORE_YELLOW << text << AFTER
//****************************************************
#endif
